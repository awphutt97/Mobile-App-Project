package com.example.appdevproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class CurrencyList extends AppCompatActivity {

    public static final String name = "com.example.appdevproject";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currency_list);
    }

    //Called when user presses currency button
    public void sendToData(View view)
    {
        Intent intent = new Intent(this, CurrencyData.class);
        Button b = (Button)view;
        String buttonTxt = b.getText().toString();
        intent.putExtra(name, buttonTxt);

        startActivity(intent);
    }
}