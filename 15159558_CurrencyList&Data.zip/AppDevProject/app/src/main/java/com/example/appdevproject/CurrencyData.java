package com.example.appdevproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class CurrencyData extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currency_data);

        Intent intent = getIntent();
        String currencyName = intent.getStringExtra(CurrencyList.name);

        TextView textView = findViewById(R.id.textView);
        textView.setText(currencyName);

        double [] values = {10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
        String[] currencies = {"bitcoin", "ethereum", "ripple", "bitcoin cash", "litecoin",
                                "eos", "cardano", "stellar", "neo", "iota"};
        double [] percentages = {-12, +30, -20, 1, 12, 9, 70, -89, 9, -12};

        double price = 0;
        double percent = 0;

        for (int i = 0; i < 10; i++)  {
            if (currencyName.toLowerCase().equals(currencies[i]))  {
            price = values[i];
            percent = percentages[i];
            }
        }

        TextView textView2 = findViewById(R.id.textView2);
        textView2.setText("Price:   " + price);

        TextView textView3 = findViewById(R.id.textView3);
        textView3.setText("% Change (24 hrs):   " + percent + "%");
    }
}